from machine import Pin
import time

# المداخل (الأزرار)
inc_button = Pin(12, Pin.IN, Pin.PULL_UP)
dec_button = Pin(14, Pin.IN, Pin.PULL_UP)

# المخارج (اللمبات)
green_led = Pin(2, Pin.OUT)   # Free Space (0-14)
red_led = Pin(4, Pin.OUT)     # Full (15)
yellow_led = Pin(5, Pin.OUT)  # Event Entry
blue_led = Pin(18, Pin.OUT)   # Event Exit

car_count = 0
MAX_CAPACITY = 15

last_inc = 1
last_dec = 1

def update_leds():
    if car_count < MAX_CAPACITY:
        green_led.value(1)
        red_led.value(0)
    else:
        green_led.value(0)
        red_led.value(1)

update_leds()

while True:
    inc_state = inc_button.value()
    dec_state = dec_button.value()

    # ضغط زر الدخول
    if inc_state == 0 and last_inc == 1:
        if car_count < MAX_CAPACITY:
            car_count += 1
            update_leds()
            yellow_led.value(1)
            time.sleep(0.2)
            yellow_led.value(0)
        time.sleep(0.1)

    # ضغط زر الخروج
    if dec_state == 0 and last_dec == 1:
        if car_count > 0:
            car_count -= 1
            update_leds()
            blue_led.value(1)
            time.sleep(0.2)
            blue_led.value(0)
        time.sleep(0.1)

    last_inc = inc_state
    last_dec = dec_state
    time.sleep(0.05)