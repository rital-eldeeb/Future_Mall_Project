# Future Mall - Product Classifier
# Task 1, Sub-task 3

from keras.models import load_model
from keras.layers import DepthwiseConv2D
from PIL import Image, ImageOps
import numpy as np

# TODO 1
categories = ["Fruits", "Vegetables", "Dairy Products"]

class TeachableMachineLayer(DepthwiseConv2D):
    def __init__(self, *args, groups=1, **kwargs):
        super().__init__(*args, **kwargs)

model = load_model(
    "keras_model.h5",
    compile=False,
    custom_objects={"DepthwiseConv2D": TeachableMachineLayer},
)

def prepare(image_path):
    image = Image.open(image_path).convert("RGB")
    image = ImageOps.fit(image, (224, 224))
    data = np.asarray(image, dtype=np.float32).reshape(1, 224, 224, 3)
    return (data / 127.5) - 1

def classify(image_path):
    scores = model.predict(prepare(image_path), verbose=0)[0]

    # TODO 2
    best_position = 0
    for i in range(1, len(scores)):
        if scores[i] > scores[best_position]:
            best_position = i

    # TODO 3
    category = categories[best_position]
    confidence = scores[best_position] * 100

    return category, confidence

# TODO 4
test_images = ["apple_test.jpg", "carrot_test.jpg", "milk_test.jpg"]

# TODO 5
for image in test_images:
    category, confidence = classify(image)
    print(f"{image}  ->  {category}  ({confidence:.0f}%)")
