def calculate_total(prices, purchased_products):
    total = 0

    for product_number in purchased_products:
        total = total + prices[product_number - 1]

    return total


mall_name = "Future Mall"

products = ["Apple Juice", "Sneakers", "Rice", "T-Shirt", "Headphones"]
prices = [25, 380, 30, 150, 220]

print("=" * 45)
print("              FUTURE MALL")
print("=" * 45)

print("\nAvailable Products:")

for i in range(5):
    print(i + 1, "-", products[i], "-", prices[i], "EGP")

print("\nEnter 0 when you finish shopping.")

purchased_products = []

while True:
    choice = int(input("Enter product number: "))

    if choice == 0:
        break

    if choice >= 1 and choice <= 5:
        purchased_products.append(choice)
    else:
        print("Invalid product number. Please try again.")


original_total = calculate_total(prices, purchased_products)

discount = 0

if original_total > 500:
    discount = original_total * 0.10

final_total = original_total - discount


print("\n")
print("=" * 45)
print("              FUTURE MALL")
print("                RECEIPT")
print("=" * 45)

print("Mall Name: Future Mall")
print("-" * 45)

print("Purchased Products:")

for product_number in purchased_products:
    print(products[product_number - 1], "-", prices[product_number - 1], "EGP")

print("-" * 45)

print("Original Total :", format(original_total, ".2f"), "EGP")
print("Discount       :", format(discount, ".2f"), "EGP")
print("Final Total    :", format(final_total, ".2f"), "EGP")

print("-" * 45)
print("Thank you for shopping at Future Mall!")
print("=" * 45)